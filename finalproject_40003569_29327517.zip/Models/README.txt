Right, so we have
    - Bed (self-explanatory)
    - Chairs
        - This includes: 
            - one in the bedroom (this'll be the throne)
            - sofas in the living room (we can use the sofa model twice; I'll get another model just in case we decide we want a new one)
    - Tables
        - This includes
            = one in the center of the living room by the couches/sofas
            - Nightstands and other small nightstand-like shelves
                - This includes (again, use the same model twice if we want; will get another):
                    - one in the bedroom, by the bed ()
                    - one in the living room, by the "north-eastern"-most couch/sofa (Tuffit0)
            
*sigh* fuck, I just remembered about gathering the authors' names. Thing is, though, I'm pretty sure we can just say "We literally made none of these objects" and be fine. 'Cause there's really not a whole lot to describe the authors in SketchUp, I mean there's their names, but I can't even see a way to search for products or downloads by Author.

Also, I know this is not at all necessary but I copied the cube.obj to the Post-Demo > Models directory. The old cube.obj is still in the general directory, so if any of your files run depending on its filepath, they'll be unaffected. But I thought it'd be cool to keep it with the other models.